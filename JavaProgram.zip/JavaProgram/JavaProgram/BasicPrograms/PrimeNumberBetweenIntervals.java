package BasicPrograms;

import java.util.Scanner;

public class PrimeNumberBetweenIntervals {
	
	static void primeNumberCalculation(int firstNumber,int lastNumber) {
		System.out.print("Prime numbers Between " +firstNumber+" and "+lastNumber+" are ");
		while(firstNumber < lastNumber) {
			boolean flag=false;
			for(int i=2;i<=firstNumber/2;i++) {
				if(firstNumber%i==0) {
					flag=true;
					break;
				}
			}
			if(flag==false)
				//System.out.println("Prime numbers are: ");
				System.out.print(firstNumber+" ");
			firstNumber++;
		}
	}

	public static void main(String[] args) {
		int firstNumber;
		int lastNumber;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the first number :");
		firstNumber=scan.nextInt();
		System.out.println("Enter the last number :");
		lastNumber=scan.nextInt();
		
	    primeNumberCalculation(firstNumber,lastNumber);
	}

}
