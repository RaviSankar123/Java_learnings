	package BasicPrograms;

import java.util.Scanner;

public class EvenNumberBetweenTwoNumbers {
	static void evenNumbersCalculation(int firstNumber, int lastNumber) {
		for(int i=firstNumber; i<=lastNumber; i++){
            if(i%2==0){
                System.out.println(i);
            }
		}
		
	}

	public static void main(String[] args) {
		int firstNumber;
		int lastNumber;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the first number :");
		firstNumber=scan.nextInt();
		System.out.println("Enter the last number :");
		lastNumber=scan.nextInt();
		
		evenNumbersCalculation(firstNumber,lastNumber);

	}

}
