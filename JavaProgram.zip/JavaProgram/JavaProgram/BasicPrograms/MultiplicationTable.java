package BasicPrograms;

import java.util.Scanner;

public class MultiplicationTable {
	
	static void tableCalculation(int n) {
		for(int i=1;i<=10;i++) {
			System.out.println(n+"*"+i+"="+i*n);
		}
		//int number = 0;
		//return n;
		
	}

	public static void main(String[] args) {
		int n;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the multiplication table number:");
		n=scan.nextInt();
		
		tableCalculation(n);

	}

}
