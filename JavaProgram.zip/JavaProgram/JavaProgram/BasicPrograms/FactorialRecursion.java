package BasicPrograms;

import java.util.Scanner;

public class FactorialRecursion {
	static int multiplyCalculation(int number) {
		if(number>1)
			return number*multiplyCalculation(number-1);
		else
			return 1;
	}

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int number;
		System.out.println("Enter the number :");
		number=scan.nextInt();
		int factorial=multiplyCalculation(number);
		
		System.out.println("The factorial of "+number+ " is "+factorial);
		
	}

}
