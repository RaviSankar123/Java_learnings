package BasicPrograms;
import java.util.Scanner;

public class perfectNumber {
	
	static void calculationForPerfectNumber(int n) {
		int sum=0;
		int originalNumber=n;
		for(int i=1;i<n;i++) {
		if(n%i==0) {
			System.out.println(i);
			sum=sum+i;
		    }
		}
		System.out.println(sum);
		if(sum==originalNumber) {
			System.out.println(n+" is a perfect number");
		    //return originalNumber;
		}
		    
		else
			System.out.println(n+" is not a perfect number");
		//return originalNumber;
	}

	public static void main(String[] args) {
		int n;
		Scanner sacn=new Scanner(System.in);
		System.out.println("enter the number :");
		n=sacn.nextInt();
		
		calculationForPerfectNumber(n);
		

	}

}
