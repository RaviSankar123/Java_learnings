package Array;

import java.util.Scanner;

public class LargestSmallestValue {
	
	static void largestSmallestElement(int Array[])
	{
		int maximum = Array[0];
		for(int i = 0;i<Array.length;i++)
		{
			if(Array[i]>maximum)
				maximum=Array[i];
		}
		System.out.println("Largest element :"+ maximum);
		
		int minimum = Array[0];
		for(int i = 0;i<Array.length;i++)
		{
			if(Array[i]<minimum)
				minimum=Array[i];
		}
		System.out.println("Smalest element :"+ minimum);
	}
	
	public static void main(String[] args) {
		int n;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the length of array");
		n=scan.nextInt();
		
		int Array[]=new int[n];
		System.out.println("Enter the array values");
		for(int i = 0;i<Array.length;i++)
		{
			Array[i]=scan.nextInt();
		}
		
		largestSmallestElement(Array);
		
	}

}
