package Array;

import java.util.Scanner;

public class SumOfArray{

	static void sumArray(int arr[])
	{	
		int sum=0;
		for(int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		System.out.println("Sum of Arrays:"+sum);
	}
	
	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		int n;
		
		System.out.println("Enter the array size:");
		n=scan.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the array values:");
		for(int i=0;i<arr.length;i++)
		{
			arr[i] = scan.nextInt();
		}
		
		sumArray(arr);
			
	}
	
}
