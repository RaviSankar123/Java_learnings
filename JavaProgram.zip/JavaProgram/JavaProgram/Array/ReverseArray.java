package Array;

import java.util.Scanner;

public class ReverseArray {
	static void reverse(int Array[]) 
	{
		for(int i=Array.length-1;i>=0;i--)
        {
			System.out.println("Reversed array :"+ Array[i]); 
        }

	}

	public static void main(String[] args) {
		
		int n;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the length of array:");
		n=scan.nextInt();
		
		int Array[]=new int[n];
		System.out.println("Enter the array values:");
		
		for(int i=0;i<Array.length;i++)
		{
			Array[i]=scan.nextInt();
		}
		reverse(Array);
		
	}

}
