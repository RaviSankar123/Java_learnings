package Array;

import java.util.Scanner;

public class ArrayOddPosition {

	static void oddPositionElements(int arr[])
	{	
		
		System.out.println("Odd position elements:");
		for(int i=0;i<arr.length;i=i+2)
		{
			System.out.println(arr[i]);
		}
	}
	
	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		int n;
		
		System.out.println("Enter the array size:");
		n=scan.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the array values:");
		for(int i=0;i<arr.length;i++)
		{
			arr[i] = scan.nextInt();
		}
		
		oddPositionElements(arr);
			
	}
	
}
