package Array;

import java.util.Scanner;

public class PalindromeElementArray {
	static void palindromeMethod(int Array[])
	{
		int remainder,reverse=0;
		int originalValue;
		 for (int i = 0; i < Array.length; i++) {
	            originalValue = Array[i];
	            while (Array[i] != 0) {
	                remainder = Array[i] % 10;
	                reverse = reverse * 10 + remainder;
	                Array[i] = Array[i] / 10;
	            }
	            if (originalValue == reverse) {
	                System.out.println(originalValue + " is a palindrome");
	            }
	            reverse = 0;
	        }
	}

	public static void main(String[] args) {
		int n;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the length of array");
		n=scan.nextInt();
		
		int Array[]=new int[n];
		System.out.println("Enter the array values");
		for(int i = 0;i<Array.length;i++)
		{
			Array[i]=scan.nextInt();
		}
		
		palindromeMethod(Array);
		
	}

}
