import java.util.Scanner;

class MiddleIndex{
    public static void main(String[] args){
        int number;
        Scanner scan=new Scanner(System.in);
        number=scan.nextInt();
        
        int arr[]=new int[number];
        for(int i=0;i<arr.length;i++){
            arr[i]=scan.nextInt();
        }
        middleIndex(arr);
    }
    static void middleIndex(int arr[]){
        int middle=arr.length/2;
        if(arr.length%2==0){
            System.out.println(arr[middle-1]);
            System.out.println(arr[middle]);
        }
        else{
            System.out.println(arr[middle]);
        }
    }
}

