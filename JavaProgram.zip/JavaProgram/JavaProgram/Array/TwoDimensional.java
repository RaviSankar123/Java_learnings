package Array;

import java.util.Scanner;
public class TwoDimensional {

	public static void main(String[] args) {
		int n,m;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the length of arrays:");
		n=scan.nextInt();
		m=scan.nextInt();
		
		int arr[][]=new int[n][m];
		
		System.out.println("Enter the values of values:");
		
		for(int i=0;i<arr.length;i++) 
		{
			for(int j=0;j<arr.length;j++) 
			{
				arr[i][j]=scan.nextInt();
			}
		}
		
		for(int i=0;i<arr.length;i++) 
		{
			for(int j=0;j<arr.length;j++) 
			{
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}   
	}

}
