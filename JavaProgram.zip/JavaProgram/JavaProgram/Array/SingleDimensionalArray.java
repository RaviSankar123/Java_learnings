package Array;

import java.util.Scanner;

public class SingleDimensionalArray{
	
	public static void main(String[] args) {
		
		int n;
		Scanner sc=new Scanner(System.in);
//		int rollno[]=new int[] {1,2,3,4,5 };
        System.out.println("Enter the length of array:");
		n=sc.nextInt();
		int rollno[]=new int[n];
		
		
//		rollno[3] = 1004;
		
		System.out.println("type ur array values");

		for(int i=0;i<rollno.length;i++)  // length
		{
			rollno[i] =sc.nextInt();
		}
		
//		System.out.println(rollno[4]);
		

		for(int i=0;i<rollno.length;i++)
		{
			System.out.println(rollno[i]);
		}
	}

}
