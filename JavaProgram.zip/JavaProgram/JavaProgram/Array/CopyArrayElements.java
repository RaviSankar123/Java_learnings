package Array;

import java.util.Scanner;

public class CopyArrayElements {

	public static void main(String[] args) {
		
		int n;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the length of array:");
		n=scan.nextInt();
		
		int originalValues[]=new int[n];
		int newValues[]=new int[originalValues.length];
		System.out.println("Enter the array values:");
		
		for(int i=0;i<originalValues.length;i++)
		{
			originalValues[i]=scan.nextInt();
			newValues[i]=originalValues[i];
		}
		for(int i=0;i<originalValues.length;i++)
		{
			System.out.println("New array:"+ newValues[i]);
		}
		
		
	}

}
