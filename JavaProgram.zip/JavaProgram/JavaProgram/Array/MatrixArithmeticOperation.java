package Array;

import java.util.Scanner;

public class MatrixArithmeticOperation {
	static void addition(int matrix1[][], int matrix2[][],int rows, int columns) {
		int resultMatrix[][]=new int[rows][columns];
		for(int i=0;i<rows;i++) {
			for(int j=0;j<columns;j++) {
				resultMatrix[i][j]=matrix1[i][j]+matrix2[i][j];
			}
		}
		
		System.out.println("First matrix:");
		for(int i=0;i<rows;i++) {
			for(int j=0;j<columns;j++) {
				System.out.print(matrix1[i][j]+" ");
			}
			System.out.println();
		}
		
		System.out.println("Second matrix:");
		for(int i=0;i<rows;i++) {
			for(int j=0;j<columns;j++) {
				System.out.print(matrix2[i][j]+" ");
			}
			System.out.println();
		}
		
		System.out.println("result matrix:");
		for(int i=0;i<rows;i++) {
			for(int j=0;j<columns;j++) {
				System.out.print(resultMatrix[i][j]+" ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		int rows,columns;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of rows:");
		rows=scan.nextInt();
		System.out.println("Enter the number of columns:");
		columns=scan.nextInt();
		
		int matrix1[][]=new int[rows][columns];
		int matrix2[][]=new int[rows][columns];
		
		System.out.println("Enter the values of matrix1:");
		for(int i=0;i<rows;i++) {
			for(int j=0;j<columns;j++) {
				matrix1[i][j]=scan.nextInt();
			}
		}
		
		System.out.println("Enter the values of matrix2:");
		for(int i=0;i<rows;i++) {
			for(int j=0;j<columns;j++) {
				matrix2[i][j]=scan.nextInt();
			}
		}
		addition(matrix1, matrix2, rows, columns);
	}

}
