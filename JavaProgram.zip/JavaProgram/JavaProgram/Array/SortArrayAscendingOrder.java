package Array;

import java.util.Scanner;

public class SortArrayAscendingOrder {
	static void ascendingOrder(int Array[]) {
		int temp=0;//declared integer variable named temp it is used to store the temporary values  during swapping process 
		for(int i=0;i<Array.length;i++) {//this loop will iterate each elelment of the array
			for(int j=i+1;j<Array.length;j++) {//this loop will iterate array elements but starting the the next index
				if(Array[i]>Array[j]) {//it check index of i > than index j, if the condition is true the array elements are not in ascending order
					temp=Array[i];
					Array[i]=Array[j];
					Array[j]=temp;
				}
			}
		}
		for(int i=0;i<Array.length;i++) {
			System.out.print(Array[i]+" ");
		}
		
	}

	public static void main(String[] args) {
		int n;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the array length:");
		n=scan.nextInt();
		
		int Array[]=new int[n];
		System.out.println("Enter the array elements:");
		for(int i=0;i<Array.length;i++) {
			Array[i]=scan.nextInt();
		}
		ascendingOrder(Array);
		
	}

}
