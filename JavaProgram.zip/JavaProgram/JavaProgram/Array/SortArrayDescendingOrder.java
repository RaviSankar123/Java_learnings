package Array;

import java.util.Scanner;

public class SortArrayDescendingOrder {
	static void ascendingOrder(int Array[]) {
		int temp=0;
		for(int i=0;i<Array.length;i++) {
			for(int j=i+1;j<Array.length;j++) {
				if(Array[i]<Array[j]) {
					temp=Array[i];
					Array[i]=Array[j];
					Array[j]=temp;
				}
			}
		}
		for(int i=0;i<Array.length;i++) {
			System.out.print(Array[i]+" ");
		}
		
	}

	public static void main(String[] args) {
		int n;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the array length:");
		n=scan.nextInt();
		
		int Array[]=new int[n];
		System.out.println("Enter the array elements:");
		for(int i=0;i<Array.length;i++) {
			Array[i]=scan.nextInt();
		}
		ascendingOrder(Array);
		
	}

}
