package Array;

import java.util.Scanner;

public class ArrayDulicateElements {
	//create a class named ArrayDulicateElements
	
	static void duplicateValue(int nums[])
	//create a method name duplicatevalue which takes the integer array
	{	
		for(int i=0;i<nums.length;i++)
			//this loop iterate each element of the array
		{
			for(int j=i+1;j<nums.length;j++)
				//this nested loop iterate element of the array starting from the next index
			{
				if(nums[i] == nums[j])
					//this line checks if the element of the index i is equal to index j
				{
					System.out.println(nums[i]);
				}
			}
		}
	}

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int n;
		
		System.out.println("Enter the array size:");
		n=scan.nextInt();
		//this line reads the array length/size
		int arr[] = new int[n];
		//this line create a integer array as arr
		System.out.println("Enter the array values:");
		for(int i=0;i<arr.length;i++)
			//this loop is user to enter the values of each array elements
		{
			arr[i] = scan.nextInt();
		}
		
		duplicateValue(arr);
	}

}
