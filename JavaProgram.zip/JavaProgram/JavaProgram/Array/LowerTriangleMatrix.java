package Array;

import java.util.Scanner;

public class LowerTriangleMatrix {
	static void lowerTriangle(int Array[][],int rows, int columns) {
		for(int i=0;i<rows;i++) {
			for(int j=0;j<columns;j++) {
				if(j>i)
					System.out.print("0 ");
				else
					System.out.print(Array[i][j]+" ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		int rows, columns;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of rows ");
		rows=scan.nextInt();
		System.out.println("Enter the number of columns ");
		columns=scan.nextInt();
		
		int Array[][]=new int[rows][columns];
		
		System.out.println("First matrix:");
		for(int i=0;i<rows;i++) {
			for(int j=0;j<columns;j++) {
				Array[i][j]=scan.nextInt();
			}
		}
		
		lowerTriangle(Array, rows, columns);

	}

}
