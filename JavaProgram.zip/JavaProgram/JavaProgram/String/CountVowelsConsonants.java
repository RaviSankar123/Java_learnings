package String;

import java.util.Scanner;

public class CountVowelsConsonants {
	static int countVowels(String message) {
		int count=0;
		for(int i=0;i<message.length();i++) {
			char currentChar=message.charAt(i);
			if(currentChar =='a'||currentChar =='e'||currentChar =='i'||currentChar =='o'||currentChar =='u') {
				count++;
			}
		}
		return count;
	
	}
	static int countConsonants(String message) {
		int total=0;
		for(int i=0;i<message.length();i++) {
			char currentChar=message.charAt(i);
			if(currentChar !='a'&&currentChar !='e'&&currentChar !='i'&&currentChar !='o'&&currentChar !='u'&&currentChar !=' ') {
				total++;
			}
		}
		return total;	
	}

	public static void main(String[] args) {
		String message;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the message:");
		message=scan.nextLine();
		
		int vowels=countVowels(message);
		int consonants=countConsonants(message);
		System.out.println("number of vowels in your message:"+vowels);
		System.out.println("number of consonants in your message:"+consonants);

	}

}
