import java.util.Scanner;

public class ReverseString{
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        String message;
        System.out.println("Enter the String:");
        message=scan.nextLine();
        
        reverse(message);
    }
    static void reverse(String message){
        for(int i=message.length()-1;i>=0;i--){
            char currentChar=message.charAt(i);
            System.out.print(currentChar);
        }
    }
}