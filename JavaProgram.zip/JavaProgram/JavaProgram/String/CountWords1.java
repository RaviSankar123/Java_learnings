package String;

import java.util.Scanner;

public class CountWords1 {
	static int countWords(String message) {
		int count=0;
		for(int i=0;i<message.length();i++) {
			char currentChar=message.charAt(i);
			if(currentChar==' '||currentChar=='\t') {
				count++;
			}
		}
		count++;
		return count;
		
	}

	public static void main(String[] args) {
		String message;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the message:");
		message=scan.nextLine();
		
		int wordCount=countWords(message);
		System.out.println("number of words:"+ wordCount);

	}

}
