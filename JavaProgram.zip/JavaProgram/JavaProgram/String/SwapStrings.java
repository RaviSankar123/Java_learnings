package String;

import java.util.Scanner;

public class SwapStrings {
	static void swapTwoStrings(String firstString, String secondString) {
		
		firstString=firstString+secondString;
		secondString=firstString.substring(0,firstString.length()-secondString.length());
		firstString=firstString.substring(secondString.length());
		System.out.println("After swap");
		System.out.println("First string:"+firstString);
		System.out.println("Second string:"+secondString);
		//return 0;
	}

	public static void main(String[] args) {
		String firstString, secondString;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the first String:");
		firstString=scan.nextLine();
		System.out.println("Enter the second String:");
		secondString=scan.nextLine();
		
		swapTwoStrings(firstString, secondString);

	}

}
