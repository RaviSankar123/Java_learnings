package String;

import java.util.Scanner;

public class DuplicateCharacter {
	static void findDuplicateCharacter(String message) {
		for(int i=0;i<message.length();i++) {
			char currentChar=message.charAt(i);
			for(int j=i+1;j<message.length();j++) {
				if(currentChar==message.charAt(j)) {
					if(message.indexOf(currentChar)<i) {
						break;
					}
					System.out.println(message.charAt(i));
					break;
				}
			}
		}
	}

	public static void main(String[] args) {
		String message;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the input:");
		message=scan.nextLine();
		
		findDuplicateCharacter(message);

	}

}
