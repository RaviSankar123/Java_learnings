package String;

import java.util.Scanner;
import java.util.StringTokenizer;

public class CountWords {
	static int countWords(String message) {
		StringTokenizer tokenizer=new StringTokenizer(message);
		int count=tokenizer.countTokens();
		return count;
	}

	public static void main(String[] args) {
		String message;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the message:");
		message=scan.nextLine();
		
		//String word = new String();
		int wordCount=countWords(message);
		System.out.println("number of words:"+ wordCount);

	}

}
