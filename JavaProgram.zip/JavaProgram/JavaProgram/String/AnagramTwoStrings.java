//for exapmle race and care are anagram, we can arrange the word race by arranging the word of care. 

package String;

import java.util.Scanner;
import java.util.Arrays;

public class AnagramTwoStrings {
	static void findAnagramStrings(String firstString, String secondString) {
		
		// Remove spaces and convert to lowercase for case-insensitive comparison
		firstString=firstString.replace("\\s","").toLowerCase();
		secondString=secondString.replaceAll("\\s","").toLowerCase();
		
		if(firstString.length()==secondString.length()) {
			//convert strings to char array
			char charArray1[]=firstString.toCharArray();
			char charArray2[]=secondString.toCharArray();
			
			//sort the char array
			Arrays.sort(charArray1);
			Arrays.sort(charArray2);
			
			boolean result=Arrays.equals(charArray1, charArray2);
			
			if(result) {
				System.out.println(firstString+" and "+secondString+" are anagram");
			}
			else
				System.out.println(firstString+" and "+secondString+" are not anagram");
		}
		else
			System.out.println(firstString+" and "+secondString+" are not anagram");
	}

	public static void main(String[] args) {
		String firstString, secondString;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the first String:");
		firstString=scan.nextLine();
		System.out.println("Enter the second String:");
		secondString=scan.nextLine();
		
		findAnagramStrings(firstString, secondString);

	}

}
