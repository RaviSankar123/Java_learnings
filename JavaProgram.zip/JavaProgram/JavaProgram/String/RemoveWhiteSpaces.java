package String;

import java.util.Scanner;

public class RemoveWhiteSpaces {
	static String removeWhiteSpace(String message) {
		
		// "\\s": This is a regular expression pattern that represents white spaces.
		return message.replaceAll("\\s","");
	}

	public static void main(String[] args) {
		String message;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the message:");
		message=scan.nextLine();
		
		String withoutWhiteSpace=removeWhiteSpace(message);
		System.out.println("String without space:"+withoutWhiteSpace);

	}

}
