import java.util.Scanner;

public class StudentResult {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter student's name:");
        String name = scanner.nextLine();
        
        System.out.println("Enter marks for three subjects:");
        int subject1 = scanner.nextInt();
        int subject2 = scanner.nextInt();
        int subject3 = scanner.nextInt();
        
        int totalMarks = subject1 + subject2 + subject3;
    
        double averageMarks = totalMarks / 3.0;
        
        System.out.println("Student Name: " + name);
        System.out.println("Total Marks: " + totalMarks);
        System.out.println("Average Marks: " + averageMarks);
        
        calculateForStudentResult(averageMarks);
    }
    
    static void calculateForStudentResult(double averageMarks){
        
        if (averageMarks >= 60) {
            System.out.println("Result: 1st Class");
        } else if (averageMarks >= 50) {
            System.out.println("Result: 2nd Class");
        } else if (averageMarks >= 35) {
            System.out.println("Result: Pass Class");
        } else {
            System.out.println("Result: Fail");
        }
    }
}
