package BasicProgramsLevel1;

import java.util.Scanner;

public class Palindrome {
	// this line create a class named palindrome
	static void palindrome(int number) {
		//this line declares the method named palindrome and the keyword static means this method belongs to the class itself
		int remainder,reverse=0;
		// declared two integer variables reaminder and reverse
		int originalNumber=number;
		//this line stores the input number varibale named originalNumber. it is used to comapre with reverse later
		while(number!=0) {
			// this wihile loop will be execute util the number becomes zero
			remainder=number%10;
			//this line calculate the remainder of the input number by divided by 10
			reverse=reverse*10+remainder;
			//this line builds the reversed number by appending the last digit
			number=number/10;
			//this line removes the last digit of input numbar byt dividing it 10
		}
		if(originalNumber==reverse)
			//this line compare trhe originalNumber and reversed number if these 2s are same the given input number is palindrome
			System.out.println(originalNumber+" is palindrome");
		else
			System.out.println(originalNumber+" is not palindrome");
			
	}

	public static void main(String[] args) {
		int number;
		//this line declare a integer variable named number
		Scanner scan=new Scanner(System.in);
		//this line create a new Scanner object named scan to read input from the user
		System.out.println("Enter the number:");
		number=scan.nextInt();
		//this line to read input from the user as interger input
		
		palindrome(number);
		//this line calls the palindrome method

	}

}
