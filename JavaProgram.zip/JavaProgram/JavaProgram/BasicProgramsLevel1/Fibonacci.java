package BasicProgramsLevel1;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		int n, firstTerm=0, secondTerm=1,nextTerm;
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter the number of series:");
		n=scan.nextInt();
		
		System.out.println("The fibonacci series of "+n+" is ");
		
		for(int i=1;i<=n;i++) {
			System.out.print(firstTerm+" ,");
			
			nextTerm=firstTerm+secondTerm;
			firstTerm=secondTerm;
			secondTerm=nextTerm;
		}
		
	}

}
