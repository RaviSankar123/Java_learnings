package BasicProgramsLevel1;

import java.util.Scanner;

public class Factorial {
	static void factorial(int number) {
		int fact = 1;
		for(int i=1;i<=number;i++) {
			fact=fact*i;
		}
		System.out.println("Factorial of "+number+" is "+fact);
	}

	public static void main(String[] args) {
		int number;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number:");
		number=scan.nextInt();
		
		factorial(number);
	}

}
/*
import java.util.Scanner;

public class Fibonacci{
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        int number,firstTerm=0, secondTerm=1;
        System.out.println("Enter the number of series:");
        number=scan.nextInt();
        
        System.out.println("Fibonacci series of "+number+" is "+firstTerm+" , "+secondTerm);
        
        fibonacci(number, firstTerm, secondTerm);
    }
    static void fibonacci(int number, int firstTerm, int secondTerm){
        int nextTerm;
        for(int i=3;i<=number;i++){
            nextTerm=firstTerm+secondTerm;
            System.out.print(nextTerm+" , ");
            firstTerm=secondTerm;
            secondTerm=nextTerm;
        }
    }
    
}
*/
