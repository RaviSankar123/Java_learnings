public class SequenceGenerator {
    public static void main(String[] args) {
        int n = 15; // Number of elements you want in the sequence
        generateSequence(n);
    }

    public static void generateSequence(int n) {
        int num = 1;
        int sum = 2;
        
        for (int i = 1; i <= n; i++) {
            System.out.print(sum + " ");
            sum += num;
            num += 2;
        }
    }
}
