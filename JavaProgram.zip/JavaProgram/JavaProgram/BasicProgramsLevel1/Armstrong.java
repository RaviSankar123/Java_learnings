package BasicProgramsLevel1;

import java.util.Scanner;

public class Armstrong {
	static void armstrong(int number) {
		int count=0, remainder, result=0;
		int originalNumber=number;//store the number value in originalNumber it will used to check wheather the number is armstrong or not
		while(number!=0) {//while loop will execute util the number becomes zero
			remainder=number%10;//this line get the last digit from the number
			count++;//then increment the count value for check the number of digit given by user
			number=number/10;//this line remove the last digit of the number
		}
		number=originalNumber;
		while(number!=0) {
			remainder=number%10;
			result+=Math.pow(remainder, count);//the value of remainder raised to the power of count
			number=number/10;
		}
		if(originalNumber==result)//if the originalNumber is equal to result the given number is armstrong if not the viven number is not armstrong
			System.out.println("The given number is armstrong");
		else
			System.out.println("The given number is not armstrong");
	}

	public static void main(String[] args) {
		int number;//in this line declared integer variable named number
		Scanner scan=new Scanner(System.in);//create an object for scanner class, it is used to get input from the user
		System.out.println("Enter the number:");
		number=scan.nextInt();//get the interger input from the user
		
		armstrong(number);//call the method named armstrong

	}

}
