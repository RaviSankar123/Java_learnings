package BasicProgramsLevel1;

import java.util.Scanner;

public class ArithmeticOperations {
	
	static void addition(int number1, int number2) {
		
		int addition=number1+number2;
		System.out.println("Addition:"+addition);
	}
	
    static void subtraction(int number1, int number2) {
		
		int subtraction=number1-number2;
		System.out.println("Subtraction:"+subtraction);
	}

    static void multiplication(int number1, int number2) {
	
	    int multiplication=number1*number2;
	    System.out.println("Multiplication:"+multiplication);
    }
 
    static void division(int number1, int number2) {
	
	    int division=number1/number2;
	    System.out.println("Division:"+division);
    }
    
    static void modulo(int number1, int number2) {
    	
    	int modulo=number1%number2;
    	System.out.println("Modulo:"+modulo);
    }
	public static void main(String[] args) {
		int number1, number2;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number 1:");
		number1=scan.nextInt();
		System.out.println("Enter the number 2:");
		number2=scan.nextInt();
		
		addition(number1,number2 );
		subtraction(number1,number2 );
		multiplication(number1,number2 );
		division(number1,number2 );
		modulo(number1,number2 );
	}

}
