package BasicProgramsLevel1;

import java.util.Scanner;

public class SwapTwoNumbers {
	static void swapTwoNumbers(int a, int b) {
		int temp;
		temp=a;
		a=b;
		b=temp;
		
		System.out.println("The value of a "+a);
		System.out.println("The value of b "+b);
	}
	static void swapTwoNumbersWithoutTemp(int a, int b) {
		int temp;
		a=a-b;
		b=a+b;
		a=b-a;
		
		System.out.println("The value of a "+a);
		System.out.println("The value of b "+b);
	}

	public static void main(String[] args) {
		int a, b;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the a:");
		a=scan.nextInt();
		System.out.println("Enter the b:");
		b=scan.nextInt();
		
		swapTwoNumbers(a, b);
		swapTwoNumbersWithoutTemp(a, b);

	}

}
