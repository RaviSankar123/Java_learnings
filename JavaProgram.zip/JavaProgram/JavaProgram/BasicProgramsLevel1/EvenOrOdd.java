package BasicProgramsLevel1;

import java.util.Scanner;

public class EvenOrOdd {
	static void evenOrOdd(int number) {
		if(number==0)
			System.out.println("The given number is zero.");
		else if(number%2==0)
			System.out.println(number+" is even");
		else
			System.out.println(number+" is odd");
	}

	public static void main(String[] args) {
		int number;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number:");
		number=scan.nextInt();
		
		evenOrOdd(number);

	}

}
