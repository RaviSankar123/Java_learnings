package BasicProgramsLevel1;

import java.util.Scanner;

public class SwitchCase {
	static void arithmeticOperator(char operator,int number1, int number2) {
		switch(operator) {
		case '+':
			System.out.println("Addition:"+ (number1+number2));
			break;
		case '-':
			System.out.println("Subtraction:"+ (number1-number2));
			break;
		case '*':
			System.out.println("Multiplication:"+ (number1*number2));
			break;
		case '/':
			System.out.println("Divition:"+ (number1/number2));
			break;
		case '%':
			System.out.println("Modulo:"+ number1%number2);
			break;	
		}
	}

	public static void main(String[] args) {
		char operator;
		int number1, number2;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the operator:");
		operator=scan.next().charAt(0);
		System.out.println("Enter the first number:");
		number1=scan.nextInt();
		System.out.println("Enter the second number:");
		number2=scan.nextInt();
		
		arithmeticOperator(operator, number1, number2);

	}

}
