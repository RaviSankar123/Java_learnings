package BasicProgramsLevel1;

import java.util.Scanner;

public class GreatestOfTwoNumbers {
	
	static void greatestOfTwoNumbers(int number1, int number2) {
		if(number1>number2) 
			System.out.println(number1+" is greater");
		else
			System.out.println(number2+" is greater");
	}

	public static void main(String[] args) {
		int number1, number2;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number 1:");
		number1=scan.nextInt();
		System.out.println("Enter the number 2:");
		number2=scan.nextInt();
		
		greatestOfTwoNumbers(number1, number2);

	}

}
