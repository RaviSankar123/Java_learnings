package BasicProgramsLevel1;

import java.util.Scanner;

public class PrimeNumber {
	static void primeNumber(int number) {
		boolean flag=false;
		for(int i=2;i<=number/2;i++) {
			if(number%i==0) {
				System.out.println(number+" is not a prime number");
				flag=true;
				break;
			}
		}
		if(flag==false)
			System.out.println(number+" is a prime number");
	}

	public static void main(String[] args) {
		int number;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number:");
		number=scan.nextInt();
		
		primeNumber(number);

	}

}
