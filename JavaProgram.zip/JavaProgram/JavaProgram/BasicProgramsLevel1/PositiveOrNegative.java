package BasicProgramsLevel1;

import java.util.Scanner;

public class PositiveOrNegative {
	
	static void positiveOrNegative(int number) {
		if(number>0) {
			System.out.println(number+" is positive numnber");
		}
		else if(number<0) {
			System.out.println(number+" is negative number");
		}
		else
			System.out.println("The given number is zero");
	}

	public static void main(String[] args) {
		int number;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number:");
		number=scan.nextInt();
		
		positiveOrNegative(number);
	}

}
