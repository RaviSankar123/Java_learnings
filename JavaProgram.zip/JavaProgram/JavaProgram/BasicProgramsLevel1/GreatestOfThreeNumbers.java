package BasicProgramsLevel1;

import java.util.Scanner;

public class GreatestOfThreeNumbers {
	
	static void greatestOfThreeNumbers(int number1,int number2,int number3) {
		 if(number1>number2 && number1>number3)
			 System.out.println(number1+" is greater");
		 else if(number2>number1 && number2>number3)
			 System.out.println(number2+" is greater");
		 else if(number3>number1 && number3>number2)
			 System.out.println(number3+" is greater");
		 else
		     System.out.println("the given numbers are equal");
	}

	public static void main(String[] args) {
		int number1, number2, number3;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number 1:");
		number1=scan.nextInt();
		System.out.println("Enter the number 2:");
		number2=scan.nextInt();
		System.out.println("Enter the number 3:");
		number3=scan.nextInt();
		
		greatestOfThreeNumbers(number1, number2, number3);

	}

}
